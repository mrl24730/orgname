# Principal UI — Principal Hong Kong Web UI components

[![Storybook][storybook-img]][docsite]
![bootstrap branch parameter](https://github.com/principalhongkong/pihk-decumulation/actions/workflows/bootstrap.yml/badge.svg?branch=main)
![principa-ui parameter](https://github.com/principalhongkong/pihk-decumulation/actions/workflows/principal-ui.yml/badge.svg?branch=main)
![webapp branch parameter](https://github.com/principalhongkong/pihk-decumulation/actions/workflows/webapp.yml/badge.svg?branch=main)
![webapi branch parameter](https://github.com/principalhongkong/pihk-decumulation/actions/workflows/webapi.yml/badge.svg?branch=main)
![principa-ui coverage][principal-ui-coverage-img]

This collection of UI components aims to provide all of the necessary building blocks for web applications in principal hong kong

# WebApp
https://d262b489idozm5.cloudfront.net/

# Stlye Guide
https://www.sketch.com/s/8dc8075e-434f-478c-814b-0158df1ef1a4

# REF

http://docs.getprooph.org/tutorial/why_event_sourcing.html

### storybook component

https://prateeksurana.me/blog/react-component-library-using-storybook-6/
https://blog.bitsrc.io/trying-rollup-for-react-applications-d3c2304d16bf
https://www.claritician.com/how-to-create-a-local-react-typescript-library-that-i-can-use-across-my-react-projects

### upgrade storybook

https://gist.github.com/shilman/8856ea1786dcd247139b47b270912324#upgrade

### Create a coverage badge
https://dev.to/thejaredwilcurt/coverage-badge-with-github-actions-finally-59fa
https://itnext.io/github-actions-code-coverage-without-third-parties-f1299747064d
https://www.freecodecamp.org/news/how-to-generate-code-coverage-report-with-codecov-and-github-actions/

### checking status for PR

https://stackoverflow.com/questions/58654530/how-to-reject-a-pull-request-if-tests-are-failed-github-actions

[storybook-img]: https://cdn.jsdelivr.net/gh/storybookjs/brand@master/badge/badge-storybook.svg
[principal-ui-coverage-img]: https://img.shields.io/endpoint?url=https://principalhongkong.github.io/pihk-decumulation/coverage/principal-ui.json
[docsite]: https://principalhongkong.github.io/pihk-decumulation/storybook


### React query
https://medium.com/@cant89/data-fetching-in-redux-is-painful-get-rid-of-it-now-2b71305268e1
