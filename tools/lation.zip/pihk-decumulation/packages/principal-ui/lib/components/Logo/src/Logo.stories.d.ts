/// <reference types="react" />
declare const _default: {
    title: string;
    component: () => JSX.Element;
};
export default _default;
export declare const Logo: any;
