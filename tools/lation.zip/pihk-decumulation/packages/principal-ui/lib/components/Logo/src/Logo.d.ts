/// <reference types="react" />
export interface LogoProps {
}
export declare const Logo: () => JSX.Element;
