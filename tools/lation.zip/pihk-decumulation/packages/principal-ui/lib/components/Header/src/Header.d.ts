/// <reference types="react" />
export interface HeaderProps {
}
export declare const Header: () => JSX.Element;
