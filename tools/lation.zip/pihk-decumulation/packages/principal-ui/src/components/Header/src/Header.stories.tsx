import React from 'react'
import { Story } from '@storybook/react'
import { Header as _Header, HeaderProps } from './Header'

export default {
  title: 'Components/Header',
  component: _Header,
}

const Template: Story<HeaderProps> = (args) => <_Header {...args} />

export const Header = Template.bind({})
