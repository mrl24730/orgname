import * as React from 'react'

export interface HeaderProps {}

export const Header = () => {
  return <header>Hello!</header>
}
