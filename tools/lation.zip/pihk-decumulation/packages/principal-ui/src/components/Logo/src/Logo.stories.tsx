import React from 'react'
import { Story } from '@storybook/react'
import { Logo as _Logo, LogoProps } from './Logo'

export default {
  title: 'Components/Logo',
  component: _Logo,
}

const Template: Story<LogoProps> = (args) => <_Logo {...args} />

export const Logo = Template.bind({})
