// import { babel } from '@rollup/plugin-babel'
import peerDepsExternal from 'rollup-plugin-peer-deps-external'
import resolve from '@rollup/plugin-node-resolve'
import commonjs from '@rollup/plugin-commonjs'
import typescript from 'rollup-plugin-typescript2'
import postcss from 'rollup-plugin-postcss'
import filesize from 'rollup-plugin-filesize'

// import alias from '@rollup/plugin-alias'

const packageJson = require('./package.json')

export default {
  input: 'src/index.ts',
  output: [
    { file: packageJson.main, format: 'cjs', sourcemap: true },
    { file: packageJson.module, format: 'esm', sourcemap: true },
  ],
  plugins: [
    peerDepsExternal(),
    resolve(),
    commonjs(),
    typescript({ useTsconfigDeclarationDir: true }),
    postcss({
      extract: false,
      modules: true,
    }),
    // babel({
    //   exclude: 'node_modules/**',
    //   presets: ['@babel/preset-react'],
    // }),
    // alias({
    //   entries: [
    //     { find: '@styles', replacement: '../../../styles/' },
    //     { find: '@assets', replacement: '../../../assets/' },
    //   ],
    // }),
    filesize(),
  ],
}
