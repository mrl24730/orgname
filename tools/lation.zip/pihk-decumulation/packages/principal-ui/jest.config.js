module.exports = {
  moduleNameMapper: {
    '^.+\\.(css|less|scss|svg)$': '<rootDir>/__mocks__/fileMock.js',
  },
  coverageReporters: ['lcov', 'text', 'cobertura', 'json-summary'],
  collectCoverageFrom: ['src/**/*.ts*'],
  modulePathIgnorePatterns: ['<rootDir>/lib/'],
}
