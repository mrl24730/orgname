import React from 'react'
import { Story, Meta } from '@storybook/react'
import { Button as ButtonComp, ButtonProps } from '../Button'

export default {
  title: 'Components/Button',
  component: ButtonComp,
}

const Template: Story<ButtonProps> = (args) => (
  <ButtonComp {...args}>Buttons</ButtonComp>
)

export const Button = Template.bind({})
