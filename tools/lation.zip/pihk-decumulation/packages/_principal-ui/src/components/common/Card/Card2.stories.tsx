import React from 'react'
import { Story } from '@storybook/react'
import { Card2 } from '../Card'

export default {
  title: 'Components/Card',
  component: Card2,
}

const Template: Story = (args) => (
  <Card2 {...args}>
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
    ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
  </Card2>
)

export const CardStyle2 = Template.bind({})
