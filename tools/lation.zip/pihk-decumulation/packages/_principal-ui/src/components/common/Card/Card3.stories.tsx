import React from 'react'
import { Story } from '@storybook/react'
import { Card3 } from '../Card'

export default {
  title: 'Components/Card',
  component: Card3,
}

const Template: Story = (args) => (
  <Card3 {...args}>
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
    ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
  </Card3>
)

export const CardStyle3 = Template.bind({})
