import React from 'react'
import { Story, Meta } from '@storybook/react'
import { Footer as FooterComp, FooterProps } from '../Footer'

export default {
  title: 'Components/Footer',
  component: FooterComp,
}

const Template: Story<FooterProps> = (args) => <FooterComp {...args} />

export const Footer = Template.bind({})
