import React from 'react'
import { Col, Container, Row } from 'react-bootstrap'

import styles from './Footer.module.scss'
import AppStoreIcon from '../../../assets/Google_Play_Store_badge_EN.svg'
import GooglePlayStoreIconEn from '@assets/Google_Play_Store_badge_EN.svg'
import PrincipalAppIcon from '@assets/Principal_App_icon.svg'
import YoutubeIcon from '@assets/Social_Youtube_0.svg'
import FacebookIcon from '@assets/Social_Facebook_0.svg'
import LinkedinIcon from '@assets/Social_Linkedin_0.svg'
import styled from 'styled-components'

const LeftRow = styled(Row)`
  @media (max-width: 767px) {
    border-bottom: ${(props) =>
      props.hidesplitter
        ? '1px solid rgba(255, 255, 255, 0)'
        : '1px solid rgba(255, 255, 255, 0.2)'};
  }
`

const RightRow = styled(Row)`
  @media (max-width: 767px) {
    border-bottom: ${(props) =>
      props.hidesplitter
        ? '1px solid rgba(255, 255, 255, 0)'
        : '1px solid rgba(255, 255, 255, 0.2)'};
  }
  @media (min-width: 992px) {
    padding-left: 140px;
  }
`

const RightContent = styled.div`
  width: 580px;
  @media (min-width: 992px) {
  }
  margin: 30px 0px 0px 0px;
  @media (max-width: 992px) {
    margin: 30px 0px 0px 10px;
  }
  @media (max-width: 768px) {
    margin: 30px 0px 0px 0px;
    padding-bottom: 50px;
    width: 320px;
  }
`

const LeftContent = styled.div`
  @media (min-width: 992px) {
    width: 530px;
  }
  margin: 30px 0px 0px 0px;
  @media (max-width: 768px) {
    margin: 30px 0px 0px 0px;
    padding-bottom: 50px;
    width: 320px;
  }
`

const DownloadIconsRow = styled(Row)`
  margin-left: 0px;
  align-items: flex-end;
  & .col {
    padding: 0px;
  }
  & .col:first-child {
    flex: 0 0;
  }
`

const HourSection = styled.div`
  margin: 0px 0px 10px 0px;
`

const OfficeContent = styled.div`
  color: #fff;
  margin: 20px 0px 0px 0px;
`

const DesktopTermText = styled.div`
  font-size: 13px;
  line-height: 20px;
  opacity: 0.4;

  &:first-child {
    margin-top: 76px;
  }

  @media (max-width: 767px) {
    display: none;
  }
`

const TermText = styled.div`
  font-size: 12px;
  line-height: 18px;
  opacity: 0.4;
  width: 320px;
  @media (min-width: 768px) {
    display: none;
  }
`

export interface FooterProps {
  // user?: {};
  // onLogin: () => void;
  // onLogout: () => void;
  // onCreateAccount: () => void;
}

export const Footer: React.FC<FooterProps> = (
  {
    // user,
    // onLogin,
    // onLogout,
    // onCreateAccount,
  },
) => (
  <footer className={styles.footer}>
    <Container fluid='md'>
      <Row className={styles['justify-content-md-center']}>
        <Col xs={12} md={6}>
          <LeftRow className='justify-content-center justify-content-md-end'>
            <LeftContent>
              <div className={styles['footer-office-address']}>
                <div className='body-1'>Office Address</div>
                <OfficeContent className='body-1'>
                  <div>30/F, Millennium City 6,</div>
                  <div>392 Kwun Tong Road, Kwun Tong,</div>
                  <div>Kowloon, Hong Kong</div>
                </OfficeContent>
              </div>
            </LeftContent>
          </LeftRow>
        </Col>
        <Col xs={12} md={6}>
          <RightRow className='justify-content-center justify-content-md-start'>
            <RightContent>
              <div className={styles['footer-general-info']}>
                <div className='body-1'>Useful links</div>
                <p>Contact us</p>
                <p>General FAQ</p>
              </div>
            </RightContent>
          </RightRow>
        </Col>
        <Col xs={12} md={6}>
          <LeftRow className='justify-content-center justify-content-md-end'>
            <LeftContent>
              <HourSection>
                <div>Office Hours</div>
                <div>Monday to Friday (9am - 6pm)</div>
              </HourSection>
              <HourSection>
                <div>Lunch Hours</div>
                <div>12:30pm - 1:30pm</div>
              </HourSection>
              <div>Closed on Saturday, Sunday and Public Holidays</div>
              <div>
                <DesktopTermText>
                  Copyright © 2021, Principal Financial Services, Inc.
                </DesktopTermText>
                <DesktopTermText>
                  Terms of Use | Privacy Statement
                </DesktopTermText>
              </div>
            </LeftContent>
            {/* <div className={styles['footer-copyright-text']}>
              <p>Copyright © 2021, Principal Financial Services, Inc.</p>
              <p>
                <a data-gtm='navigation-footer' href='/zh/terms-of-use'>
                  Terms of Use
                </a>
                <a data-gtm='navigation-footer' href='/zh/privacy-statement'>
                  Privacy Statement
                </a>
              </p>
            </div> */}
          </LeftRow>
        </Col>
        <Col xs={12} md={6}>
          <RightRow
            hidesplitter='true'
            className='justify-content-center justify-content-md-start'
          >
            <RightContent>
              <div className={styles['footer-follow-us']}>
                <div className='body-1'>Follow us</div>
                <div className={styles['footer-follow-icon']}>
                  <a
                    data-gtm='navigation-footer'
                    target='_blank'
                    title='Linkedin'
                    href='https://hk.linkedin.com/organization-guest/company/principalhongkong'
                  >
                    <img src={LinkedinIcon} />
                  </a>
                </div>
                <div className={styles['footer-follow-icon']}>
                  <a
                    data-gtm='navigation-footer'
                    target='_blank'
                    title='Linkedin'
                    href='https://hk.linkedin.com/organization-guest/company/principalhongkong'
                  >
                    <img src={FacebookIcon} />
                  </a>
                </div>
                <div className={styles['footer-follow-icon']}>
                  <a
                    data-gtm='navigation-follow-footer'
                    target='_blank'
                    title='Linkedin'
                    href='https://hk.linkedin.com/organization-guest/company/principalhongkong'
                  >
                    <img src={YoutubeIcon} />
                  </a>
                </div>
                <div style={{ clear: 'both' }}></div>
              </div>

              <div className={styles['footer-download-app']}>
                <h4>Download Principal Mobile MPF Centre</h4>
                <div>
                  <DownloadIconsRow>
                    <Col>
                      <div className={styles['footer-company-icon']}>
                        <img src={PrincipalAppIcon} />
                      </div>
                    </Col>
                    <Col>
                      <div className={styles['footer-download-app-icon']}>
                        <a
                          data-gtm='navigation-footer'
                          target='_blank'
                          title='Apple'
                          href='https://apps.apple.com/hk/app/principal-mobile-mpf-centre/id730843326'
                        >
                          <img src={AppStoreIcon} />
                        </a>
                      </div>
                      <div className={styles['footer-download-app-icon']}>
                        <a
                          data-gtm='navigation-footer'
                          target='_blank'
                          title='Google Play store'
                          href='https://play.google.com/store/apps/details?id=principal.PTC.PrincipalHK'
                        >
                          <img src={GooglePlayStoreIconEn} />
                        </a>
                      </div>
                    </Col>
                  </DownloadIconsRow>
                </div>
              </div>
              <div></div>
            </RightContent>
          </RightRow>
        </Col>
        <Col xs={12} md={6}>
          <LeftRow
            hidesplitter='true'
            className='justify-content-center justify-content-md-end'
          >
            <TermText>
              Copyright © 2021, Principal Financial Services, Inc.
            </TermText>
            <TermText>Terms of Use | Privacy Statement</TermText>
          </LeftRow>
        </Col>
      </Row>
    </Container>
  </footer>
)

export default Footer
