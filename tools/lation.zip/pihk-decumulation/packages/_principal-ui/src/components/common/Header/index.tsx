import { Container, Col, Row } from 'react-bootstrap'
import React from 'react'
import styles from './Header.module.scss'
import Logo from '@assets/Principal-Logo.svg'
import LangTC from '@assets/Language-TC.svg'

export interface HeaderProps {}

export const Header = (props: HeaderProps) => {
  return (
    <div className={styles.container}>
      <div className={styles.leftCol}>
        <img src={Logo} className={styles.logo} />
        <span className={styles.title}>|</span>

        <span className={styles.menuItem}>Decumulation</span>
      </div>
      <div className={styles.rightCol}>
        <a href='/'>
          <div>
            <img src={LangTC} className={styles.lang} />
          </div>
        </a>
      </div>
      <div className={styles.rightCol}></div>
    </div>
  )
}

export default Header
