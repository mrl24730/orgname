import React, { HtmlHTMLAttributes } from 'react'
import { Button as BootrapButton } from 'react-bootstrap'
import styled from '@emotion/styled'

export interface ButtonProps {
  btnType?: 'primary' | 'secondary' | 'action' | 'underline'
  type?: 'button' | 'submit' | 'reset'
  mobileFluid?: boolean // fluid 100% width for mobile
  disabled?: boolean
  active?: boolean // used with btnType: 'underline' to change style
}

// export const Button = ({
//   btnType = 'primary',
//   type = 'button',
//   disabled = false,
//   mobileFluid = false,
//   active = false,
//   ...props
// }: ButtonProps & HtmlHTMLAttributes<any>) => {
//   return (
//     <div className='button-cont'>
//       <button
//         className={`${btnType}${mobileFluid ? ' fluid' : ''}${
//           active ? ' active' : ''
//         }`}
//         disabled={disabled}
//         type={type}
//         {...props}
//       >
//         {props.children}
//       </button>
//     </div>
//   )
// }

export const Button = styled(BootrapButton)`
  color: hotpink;
`

export default Button
