import { Card } from 'react-bootstrap'
import styled from 'styled-components'

const variants = {
  small: `
  padding: 15px 15px;
  @media (min-width: 576px) {
    padding: 32px 24px;
  }
  `,
  medium: `
  padding: 30px 20px;
  @media (min-width: 576px) {
    padding: 44px 64px;
  }
  `,
}

export const StyledCard = styled(Card)`
  box-shadow: 0 0 5px 0 rgb(70 78 126 / 0.03), 0 0 30px 0 rgb(70 78 126 / 0.1);
  border: none;
  border-radius: 15px;
  margin-bottom: 30px;
  ${(props: any) => {
    switch (props.variants) {
      case 'small':
        return variants['small']
      case 'medium':
        return variants['medium']
    }
  }}
`
export default StyledCard

/**
 * Ref:
 *  desktop: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/Vrd0Yjl
 *  mobile: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/PGlq7dx
 */
export const Card2 = styled(Card)`
  box-shadow: 0 0 5px 0 rgb(70 78 126 / 0.03), 0 0 30px 0 rgb(70 78 126 / 0.1);
  border: none;
  padding: 30px 20px;
  @media (min-width: 576px) {
    padding: 44px 64px;
  }
`

/**
 * Ref:
 *  desktop: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/OmOZEvk
 *  mobile: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/DPnQM54
 */
export const Card3 = styled(Card)`
  box-shadow: 0 0 5px 0 rgb(70 78 126 / 0.03), 0 0 30px 0 rgb(70 78 126 / 0.1);
  border: none;
  padding: 15px 15px;
  @media (min-width: 576px) {
    padding: 32px 24px;
  }
`
