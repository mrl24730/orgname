import React from 'react'
import { Story, Meta } from '@storybook/react'
import { Header as HeaderComp, HeaderProps } from '../Header'

export default {
  title: 'Components/Header',
  component: HeaderComp,
}

const Template: Story<HeaderProps> = (args) => <HeaderComp {...args} />

export const Header = Template.bind({})
