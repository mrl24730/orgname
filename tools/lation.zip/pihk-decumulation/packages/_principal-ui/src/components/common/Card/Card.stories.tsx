import React from 'react'
import { Story } from '@storybook/react'
import CardComp from '../Card'

export default {
  title: 'Components/Card',
  component: CardComp,
}

const Template: Story = (args) => (
  <CardComp {...args}>
    Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo
    ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et
  </CardComp>
)

export const ShodowOnly = Template.bind({})
