import Footer from './components/common/Footer'
import Header from './components/common/Header'
import { StyledCard as Card, Card2, Card3 } from './components/common/Card'

export { Header, Footer, Card, Card2, Card3 }
