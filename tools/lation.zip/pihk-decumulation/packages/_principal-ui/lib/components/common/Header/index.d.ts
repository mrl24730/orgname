/// <reference types="react" />
export interface HeaderProps {
}
export declare const Header: (props: HeaderProps) => JSX.Element;
export default Header;
