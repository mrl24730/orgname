/// <reference types="react" />
export declare const StyledCard: import("styled-components").StyledComponent<import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap").CardProps> & {
    Img: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"img", import("react-bootstrap").CardImgProps>;
    Title: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Subtitle: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Body: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    Link: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"a", unknown>;
    Text: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"p", unknown>;
    Header: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap/esm/CardHeader").CardHeaderProps>;
    Footer: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    ImgOverlay: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
}, any, {}, never>;
export default StyledCard;
/**
 * Ref:
 *  desktop: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/Vrd0Yjl
 *  mobile: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/PGlq7dx
 */
export declare const Card2: import("styled-components").StyledComponent<import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap").CardProps> & {
    Img: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"img", import("react-bootstrap").CardImgProps>;
    Title: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Subtitle: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Body: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    Link: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"a", unknown>;
    Text: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"p", unknown>;
    Header: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap/esm/CardHeader").CardHeaderProps>;
    Footer: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    ImgOverlay: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
}, any, {}, never>;
/**
 * Ref:
 *  desktop: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/OmOZEvk
 *  mobile: https://www.sketch.com/s/5be32bbe-bf53-43ce-bdde-7a7df9b41ba6/a/DPnQM54
 */
export declare const Card3: import("styled-components").StyledComponent<import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap").CardProps> & {
    Img: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"img", import("react-bootstrap").CardImgProps>;
    Title: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Subtitle: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<import("react").ForwardRefExoticComponent<Pick<import("react").DetailedHTMLProps<import("react").HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof import("react").HTMLAttributes<HTMLDivElement>> & import("react").RefAttributes<HTMLDivElement>>, unknown>;
    Body: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    Link: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"a", unknown>;
    Text: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"p", unknown>;
    Header: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap/esm/CardHeader").CardHeaderProps>;
    Footer: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    ImgOverlay: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
}, any, {}, never>;
