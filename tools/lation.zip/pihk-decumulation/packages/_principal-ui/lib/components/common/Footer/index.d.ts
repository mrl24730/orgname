import React from 'react';
export interface FooterProps {
}
export declare const Footer: React.FC<FooterProps>;
export default Footer;
