import React from 'react';
declare const _default: {
    title: string;
    component: import("styled-components").StyledComponent<import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap").CardProps> & {
        Img: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"img", import("react-bootstrap").CardImgProps>;
        Title: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<React.ForwardRefExoticComponent<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & React.RefAttributes<HTMLDivElement>>, unknown>;
        Subtitle: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<React.ForwardRefExoticComponent<Pick<React.DetailedHTMLProps<React.HTMLAttributes<HTMLDivElement>, HTMLDivElement>, "key" | keyof React.HTMLAttributes<HTMLDivElement>> & React.RefAttributes<HTMLDivElement>>, unknown>;
        Body: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
        Link: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"a", unknown>;
        Text: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"p", unknown>;
        Header: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", import("react-bootstrap/esm/CardHeader").CardHeaderProps>;
        Footer: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
        ImgOverlay: import("react-bootstrap/esm/helpers").BsPrefixRefForwardingComponent<"div", unknown>;
    }, any, {}, never>;
};
export default _default;
export declare const CardStyle3: ((args: import("@storybook/react").Args, context: import("@storybook/react").StoryContext) => import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType) & import("@storybook/addons").BaseStoryObject<import("@storybook/react").Args, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType> & import("@storybook/addons").Annotations<import("@storybook/react").Args, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType>;
