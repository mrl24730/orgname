import React from 'react';
import { ButtonProps } from '../Button';
declare const _default: {
    title: string;
    component: import("@emotion/styled-base").StyledComponent<import("react-bootstrap/esm/helpers").Omit<any, import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps> & import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps & {
        children?: React.ReactNode;
    }, Pick<import("react-bootstrap/esm/helpers").Omit<any, import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps> & import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps & {
        children?: React.ReactNode;
    }, string | number | symbol>, object>;
};
export default _default;
export declare const Button: ((args: ButtonProps, context: import("@storybook/react").StoryContext) => import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType) & import("@storybook/addons").BaseStoryObject<ButtonProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType> & import("@storybook/addons").Annotations<ButtonProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType>;
