import React from 'react';
export interface ButtonProps {
    btnType?: 'primary' | 'secondary' | 'action' | 'underline';
    type?: 'button' | 'submit' | 'reset';
    mobileFluid?: boolean;
    disabled?: boolean;
    active?: boolean;
}
export declare const Button: import("@emotion/styled-base").StyledComponent<import("react-bootstrap/esm/helpers").Omit<any, import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps> & import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps & {
    children?: React.ReactNode;
}, Pick<import("react-bootstrap/esm/helpers").Omit<any, import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps> & import("react-bootstrap/esm/helpers").BsPrefixProps<React.ElementType<any>> & import("react-bootstrap").ButtonProps & {
    children?: React.ReactNode;
}, string | number | symbol>, object>;
export default Button;
