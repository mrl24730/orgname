/// <reference types="react" />
import { HeaderProps } from '../Header';
declare const _default: {
    title: string;
    component: (props: HeaderProps) => JSX.Element;
};
export default _default;
export declare const Header: ((args: HeaderProps, context: import("@storybook/react").StoryContext) => import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType) & import("@storybook/addons").BaseStoryObject<HeaderProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType> & import("@storybook/addons").Annotations<HeaderProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType>;
