import React from 'react';
import { FooterProps } from '../Footer';
declare const _default: {
    title: string;
    component: React.FC<FooterProps>;
};
export default _default;
export declare const Footer: ((args: FooterProps, context: import("@storybook/react").StoryContext) => import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType) & import("@storybook/addons").BaseStoryObject<FooterProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType> & import("@storybook/addons").Annotations<FooterProps, import("@storybook/react/dist/ts3.9/client/preview/types").StoryFnReactReturnType>;
