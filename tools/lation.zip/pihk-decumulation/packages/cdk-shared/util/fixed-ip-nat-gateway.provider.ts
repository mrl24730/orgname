import {
  NatProvider,
  CfnNatGateway,
  ConfigureNatOptions,
  GatewayConfig,
  PrivateSubnet,
  RouterType,
} from '@aws-cdk/aws-ec2'

export interface FixedIpNatGatewayProviderProps {
  allocationIds: string[]
}

export class FixedIpNatGatewayProvider extends NatProvider {
  private gateways: PrefSet<string> = new PrefSet<string>()

  private allocationIds: string[] = []

  constructor(private props: FixedIpNatGatewayProviderProps) {
    super()
    this.allocationIds = props.allocationIds
  }

  public configureNat(options: ConfigureNatOptions) {
    // Create the NAT gateways
    for (const sub of options.natSubnets) {
      if (this.allocationIds.length > 0) {
        sub.addNatGateway = () => {
          const test = this.allocationIds[0]

          const ngw = new CfnNatGateway(sub, `NATGateway`, {
            subnetId: sub.subnetId,
            allocationId: this.allocationIds[0],
          })
          this.allocationIds.shift()
          return ngw
        }
      }

      const gateway = sub.addNatGateway()
      this.gateways.add(sub.availabilityZone, gateway.ref)
    }
    // Add routes to them in the private subnets
    for (const sub of options.privateSubnets) {
      this.configureSubnet(sub)
    }
  }

  public configureSubnet(subnet: PrivateSubnet) {
    const az = subnet.availabilityZone
    const gatewayId = this.gateways.pick(az)
    subnet.addRoute('DefaultRoute', {
      routerType: RouterType.NAT_GATEWAY,
      routerId: gatewayId,
      enablesInternetConnectivity: true,
    })
  }

  public get configuredGateways(): GatewayConfig[] {
    return this.gateways
      .values()
      .map((x: any[]) => ({ az: x[0], gatewayId: x[1] }))
  }
}

class PrefSet<A> {
  private readonly map: Record<string, A> = {}
  private readonly vals = new Array<[string, A]>()
  private next: number = 0

  public add(pref: string, value: A) {
    this.map[pref] = value
    this.vals.push([pref, value])
  }

  public pick(pref: string): A {
    if (this.vals.length === 0) {
      throw new Error('Cannot pick, set is empty')
    }

    if (pref in this.map) {
      return this.map[pref]
    }
    return this.vals[this.next++ % this.vals.length][1]
  }

  public values(): Array<[string, A]> {
    return this.vals
  }
}
