import { IConstruct, Tags } from '@aws-cdk/core'

export class TagHelper {
  static addBaseTags(nameTag: string, scope: IConstruct) {
    if (!nameTag) {
      throw 'Please provide the name'
    }
    Tags.of(scope).add('Name', nameTag)
    Tags.of(scope).add('pfg-privacy-class', 'medium')
    Tags.of(scope).add('pfg-app-inventory-id', 'no-entry')
    Tags.of(scope).add('pfg-data-class', 'internal')
    Tags.of(scope).add('pfg-owner', 'TBC')
    Tags.of(scope).add('pfg-cost-center', 'TBC')
  }
}
