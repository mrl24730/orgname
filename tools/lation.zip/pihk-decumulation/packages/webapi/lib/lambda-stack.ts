import * as cdk from '@aws-cdk/core'
import {
  CorsHttpMethod,
  DomainName,
  HttpApi,
  HttpAuthorizer,
  HttpAuthorizerType,
  HttpMethod,
  HttpRoute,
  HttpStage,
} from '@aws-cdk/aws-apigatewayv2'
import { ApiBase } from '@aws-cdk/aws-apigatewayv2/lib/common/base'
import { Construct, Duration, Fn, NestedStack, Tags } from '@aws-cdk/core'
import {
  IVpc,
  Peer,
  Port,
  SecurityGroup,
  SubnetType,
  Vpc,
} from '@aws-cdk/aws-ec2'
import { join } from 'path'
import { NodejsFunction } from '@aws-cdk/aws-lambda-nodejs'
import { Runtime, LayerVersion } from '@aws-cdk/aws-lambda'
import { LambdaProxyIntegration } from '@aws-cdk/aws-apigatewayv2-integrations'
import { ManagedPolicy } from '@aws-cdk/aws-iam'
import * as dynamodb from '@aws-cdk/aws-dynamodb'
import { EXPORT_PROSPECT_TABLE_ARN_NAME } from '@pihk-decumulation/cdk-shared/constants'

interface WebapiStackStackProps extends cdk.NestedStackProps {
  vpc: IVpc
}

export class LambdaStack extends cdk.NestedStack {
  httpApi: HttpApi

  constructor(scope: cdk.Construct, id: string, props: WebapiStackStackProps) {
    super(scope, id, props)

    const { vpc } = props

    const prospectTableArn = Fn.importValue(EXPORT_PROSPECT_TABLE_ARN_NAME)
    const prospectTable = dynamodb.Table.fromTableArn(
      this,
      'prospectTable',
      prospectTableArn,
    )

    this.httpApi = new HttpApi(scope, 'DecumulationHttpApi', {
      apiName: 'decumulation-hk-apigateway',
      corsPreflight: {
        allowOrigins: ['*'],
        allowHeaders: ['*'],
        allowMethods: [CorsHttpMethod.ANY],
        exposeHeaders: ['*'],
      },
      // defaultAuthorizer: agentIdpAuthorizer,
      // defaultDomainMapping: {
      //   domainName: EEnrollmentDomainName,
      //   mappingKey: 'v1',
      // },
    })
    Tags.of(this.httpApi).add('Name', 'decumulation-hk-apigateway')

    const lambdaSecurityGroup = new SecurityGroup(
      scope,
      'decumulation-hk-lambda-sg',
      {
        vpc,
        securityGroupName: 'decumulation-hk-lambda',
        allowAllOutbound: true,
      },
    )
    lambdaSecurityGroup.addIngressRule(
      Peer.anyIpv4(),
      Port.tcp(80),
      'HTTP - Inbound',
    )
    lambdaSecurityGroup.addIngressRule(
      Peer.anyIpv4(),
      Port.tcp(443),
      'HTTPS - Inbound',
    )
    Tags.of(lambdaSecurityGroup).add('Name', 'decumulation-hk-lambda')

    const lambdaRootPath = join(__dirname, '/../src/lambda/')

    const defaultFunctionProps = {
      vpc: vpc,
      vpcSubnets: { subnetType: SubnetType.PRIVATE },
      securityGroups: [lambdaSecurityGroup],
    }

    const checkFunction = createNodejsFunction(
      scope,
      'checkFunction',
      defaultFunctionProps,
      join(lambdaRootPath, 'check.ts'),
    )
    const createProspectFunction = createNodejsFunction(
      scope,
      'createProspectFunction',
      defaultFunctionProps,
      join(lambdaRootPath, 'prospect/create.ts'),
      {
        PROSPECT_TABLE_NAME: prospectTable.tableName,
      },
    )
    const getProspectByIdFunction = createNodejsFunction(
      scope,
      'getProspectByIdFunction',
      defaultFunctionProps,
      join(lambdaRootPath, 'prospect/get-by-id.ts'),
      {
        PROSPECT_TABLE_NAME: prospectTable.tableName,
      },
    )
    const updateProspectByIdFunction = createNodejsFunction(
      scope,
      'updateProspectByIdFunction',
      defaultFunctionProps,
      join(lambdaRootPath, 'prospect/update.ts'),
      {
        PROSPECT_TABLE_NAME: prospectTable.tableName,
      },
    )
    // const layerArn = `arn:aws:lambda:ap-east-1:519774774795:layer:LambdaInsightsExtension:8`
    // const layer = LayerVersion.fromLayerVersionArn(
    //   this,
    //   `LayerFromArn`,
    //   layerArn,
    // )

    this.httpApi.addRoutes({
      path: '/check',
      methods: [HttpMethod.GET],
      integration: new LambdaProxyIntegration({
        handler: checkFunction,
      }),
    })
    this.httpApi.addRoutes({
      path: '/prospects',
      methods: [HttpMethod.POST],
      integration: new LambdaProxyIntegration({
        handler: createProspectFunction,
      }),
    })
    this.httpApi.addRoutes({
      path: '/prospects/{id}',
      methods: [HttpMethod.GET],
      integration: new LambdaProxyIntegration({
        handler: getProspectByIdFunction,
      }),
    })
    this.httpApi.addRoutes({
      path: '/prospects/{id}',
      methods: [HttpMethod.PUT],
      integration: new LambdaProxyIntegration({
        handler: updateProspectByIdFunction,
      }),
    })

    prospectTable.grantReadWriteData(createProspectFunction)
    prospectTable.grant(createProspectFunction, 'dynamodb:DescribeTable')
    prospectTable.grantReadData(getProspectByIdFunction)
    prospectTable.grant(getProspectByIdFunction, 'dynamodb:DescribeTable')
    prospectTable.grantReadWriteData(updateProspectByIdFunction)
    prospectTable.grant(updateProspectByIdFunction, 'dynamodb:DescribeTable')
  }
}

function createNodejsFunction(
  scope: Construct,
  id: string,
  defaultFunctionProps: any,
  entry: string,
  environment?: any,
) {
  const func = new NodejsFunction(scope, id, {
    ...defaultFunctionProps,
    timeout: Duration.seconds(30),
    runtime: Runtime.NODEJS_14_X, // execution environment
    entry,
    handler: 'handler',
    environment,
  })
  if (func.role) {
    func.role.addManagedPolicy(
      ManagedPolicy.fromAwsManagedPolicyName(
        'CloudWatchLambdaInsightsExecutionRolePolicy',
      ),
    )
  }

  return func
}
