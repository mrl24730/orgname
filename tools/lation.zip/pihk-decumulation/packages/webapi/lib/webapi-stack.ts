import { Vpc } from '@aws-cdk/aws-ec2'
import * as cdk from '@aws-cdk/core'
import { CfnOutput } from '@aws-cdk/core'
import { LambdaStack } from './lambda-stack'

export class WebapiStack extends cdk.Stack {
  lambdaResources: LambdaStack

  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props)

    // this.vpcResources = new VpcStack(this, 'vpc-resources')
    // const { vpc } = this.vpcResources
    const vpc = Vpc.fromLookup(this, 'importedVpc', {
      vpcName: 'decumulation-hk-networking/decumulation-hk-vpc',
    })

    this.lambdaResources = new LambdaStack(this, 'webapi-resources', { vpc })

    new CfnOutput(this, 'CfnOutputLambdaHttpApiGatewayEndpoint', {
      description: 'The HttpApi gateway endpoint of the lambda',
      exportName: 'DecumulationLambdaHttpApiGatewayEndpoint',
      value: this.lambdaResources.httpApi.apiEndpoint,
    })
  }
}
