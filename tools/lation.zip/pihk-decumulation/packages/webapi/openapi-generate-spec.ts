import * as swaggerJsdoc from 'swagger-jsdoc'
import * as fs from 'fs'

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'pihk-decumulation api',
      version: '1.0.0',
    },
  },
  apis: ['./src/lambda/**/*.ts', './src/model/**/*.ts'], // files containing annotations as above
}

const openapiSpecification = swaggerJsdoc(options)
console.log(__dirname)
fs.writeFileSync('swagger.json', JSON.stringify(openapiSpecification))
