/**
 * @openapi
 * components:
 *   schemas:
 *     ContactInformationDto:
 *       type: object
 *       properties:
 *         lastName:
 *           type: string
 *         firstName:
 *           type: string
 *         mobileCountryCode:
 *           type: integer
 *         mobileNumber:
 *           type: integer
 *         email:
 *           type: string
 *         isUSperson:
 *           type: boolean
 *       required:
 *         - lastName
 *         - firstName
 *         - mobileCountryCode
 *         - mobileNumber
 *         - email
 *         - isUSperson
 */
export class ContactInformation {
  lastName: string
  firstName: string
  mobileCountryCode: number
  mobileNumber: number
  email: string
  isUSperson: boolean
}
