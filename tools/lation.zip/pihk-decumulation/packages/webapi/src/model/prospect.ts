import * as dynamoose from 'dynamoose'
import { Document } from 'dynamoose/dist/Document'
import ProspectSchema from '../schema/prospect.schema'
import { ContactInformation } from './contact-information'

/**
 * @openapi
 * components:
 *   schemas:
 *     CreateProspectRequestDto:
 *       type: object
 *       properties:
 *         contactInformation:
 *           $ref: '#/components/schemas/ContactInformationDto'
 *     CreateProspectResponseDto:
 *       type: object
 *       properties:
 *         contactInformation:
 *           $ref: '#/components/schemas/ContactInformationDto'
 */
export class Prospect extends Document {
  id: string
  contactInformation: ContactInformation
}

export const prospectModel = (tableName: string) =>
  dynamoose.model<Prospect>(tableName, ProspectSchema, { create: false })
