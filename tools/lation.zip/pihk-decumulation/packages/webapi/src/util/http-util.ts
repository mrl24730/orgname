import { APIGatewayProxyResultV2 } from 'aws-lambda'

export class HttpUtils {
  static createResponseRaw(
    statusCode: number,
    bodyText: string,
    headers: { [k: string]: string },
    isBase64Encoded: boolean,
  ): APIGatewayProxyResultV2 {
    let result = {
      statusCode,
      headers: {
        'Access-Control-Allow-Origin': '*',
      },
    }
    if (headers) {
      result = Object.assign(result, { body: bodyText })
    }

    return {
      statusCode,
      headers: {
        'Access-Control-Allow-Origin': '*',
        ...headers,
      },
      body: bodyText,
      isBase64Encoded,
    }
  }

  static createJsonResponse(
    statusCode: number,
    responseBody?: Object,
  ): APIGatewayProxyResultV2 {
    let result = {
      statusCode,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json',
      },
    }
    if (responseBody) {
      result = Object.assign(result, { body: JSON.stringify(responseBody) })
    }

    return result
  }

  static createResponse(
    statusCode: number,
    message: string,
  ): APIGatewayProxyResultV2 {
    return HttpUtils.createJsonResponse(statusCode, { message })
  }

  static createResponseWithoutBody(
    statusCode: number,
  ): APIGatewayProxyResultV2 {
    return HttpUtils.createJsonResponse(statusCode)
  }
}
