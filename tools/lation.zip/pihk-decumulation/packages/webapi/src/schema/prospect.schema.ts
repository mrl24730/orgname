import * as dynamoose from 'dynamoose'
import ContactInformationSchema from './contact-information.schema'

const ProspectSchema = new dynamoose.Schema(
  {
    id: {
      hashKey: true,
      type: String,
    },
    contactInformation: ContactInformationSchema,
  },
  {
    saveUnknown: false,
    timestamps: true,
  },
)

export default ProspectSchema
