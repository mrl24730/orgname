import * as dynamoose from 'dynamoose'

const ContactInformationSchema = new dynamoose.Schema({
  firstName: {
    type: String,
    required: true,
  },
  lastName: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
  },
  mobileCountryCode: {
    type: Number,
    required: true,
  },
  mobileNumber: {
    type: Number,
    required: true,
  },
  isUSperson: {
    type: Boolean,
    required: true,
  },
})

export default ContactInformationSchema
