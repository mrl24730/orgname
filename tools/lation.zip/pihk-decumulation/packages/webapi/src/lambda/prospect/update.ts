import { v4 as uuidv4 } from 'uuid'
import { HttpUtils } from '../../util/http-util'
import { Prospect, prospectModel } from '../../model/prospect'
import { CreateProspectRequestDto } from '../../../generated/ts/api-client'
import { ContactInformation } from '../../model/contact-information'
import { CreateProspectResponseDto } from '../../../generated/ts/api-client/models/CreateProspectResponseDto'

const PROSPECT_TABLE_NAME = process.env.PROSPECT_TABLE_NAME || ''

/**
 * @openapi
 * /prospects/{id}:
 *   put:
 *     summary: Update a prospect by id.
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The prospect id
 *     requestBody:
 *       description: Create a new prospect
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateProspectRequestDto'
 *     responses:
 *       200:
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CreateProspectResponseDto'
 */
export const handler = async (event: any) => {
  const id = event.pathParameters ? event.pathParameters.id : null
  console.log(`Calling /patch prospect, id=${id}`)
  if (event && event.body) {
    const request: CreateProspectRequestDto = JSON.parse(event.body)
    if (request) {
      console.log('Calling /update prospect', request)

      const model = prospectModel(PROSPECT_TABLE_NAME)

      const prospect = {
        contactInformation: {
          lastName: request.contactInformation?.lastName,
          firstName: request.contactInformation?.firstName,
          email: request.contactInformation?.email,
          mobileCountryCode: request.contactInformation?.mobileCountryCode,
          mobileNumber: request.contactInformation?.mobileNumber,
          isUSperson: request.contactInformation?.isUSperson,
        } as ContactInformation,
      } as Prospect

      const updatedProspect = await model.update({ id }, prospect)
      console.log('updatedProspect', updatedProspect)
    }
    return HttpUtils.createResponseWithoutBody(200)
  }

  return HttpUtils.createResponseWithoutBody(400)
}
