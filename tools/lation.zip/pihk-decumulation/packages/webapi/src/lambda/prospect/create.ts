import { v4 as uuidv4 } from 'uuid'
import { HttpUtils } from '../../util/http-util'
import { Prospect, prospectModel } from '../../model/prospect'
import { CreateProspectRequestDto } from '../../../generated/ts/api-client'
import { ContactInformation } from '../../model/contact-information'

const PROSPECT_TABLE_NAME = process.env.PROSPECT_TABLE_NAME || ''

/**
 * @openapi
 * /prospects:
 *   post:
 *     summary: Create a new prospect.
 *     requestBody:
 *       description: Create a new prospect
 *       content:
 *         application/json:
 *           schema:
 *             $ref: '#/components/schemas/CreateProspectRequestDto'
 *     responses:
 *       201:
 *         description: Created
 */
export const handler = async (event: any) => {
  if (event && event.body) {
    const request: CreateProspectRequestDto = JSON.parse(event.body)
    if (request) {
      console.log('Calling /create prospect', request)

      const model = prospectModel(PROSPECT_TABLE_NAME)

      const document = {
        id: uuidv4(),
        contactInformation: {
          lastName: request.contactInformation?.lastName,
          firstName: request.contactInformation?.firstName,
          email: request.contactInformation?.email,
          mobileCountryCode: request.contactInformation?.mobileCountryCode,
          mobileNumber: request.contactInformation?.mobileNumber,
          isUSperson: request.contactInformation?.isUSperson,
        } as ContactInformation,
      } as Prospect

      const writeResponse = await model.create(document)
      console.log('writeResponse', writeResponse)
    }
    return HttpUtils.createResponseWithoutBody(201)
  }

  return HttpUtils.createResponseWithoutBody(400)
}
