import { v4 as uuidv4 } from 'uuid'
import { HttpUtils } from '../../util/http-util'
import { Prospect, prospectModel } from '../../model/prospect'
import { CreateProspectRequestDto } from '../../../generated/ts/api-client'
import { ContactInformation } from '../../model/contact-information'
import { CreateProspectResponseDto } from '../../../generated/ts/api-client/models/CreateProspectResponseDto'

const PROSPECT_TABLE_NAME = process.env.PROSPECT_TABLE_NAME || ''

/**
 * @openapi
 * /prospects/{id}:
 *   get:
 *     summary: Retireve a prospect by id.
 *     parameters:
 *       - in: path
 *         name: id
 *         schema:
 *           type: string
 *         required: true
 *         description: The prospect id
 *     responses:
 *       200:
 *         description: OK
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/CreateProspectResponseDto'
 */
export const handler = async (event: any) => {
  const id = event.pathParameters ? event.pathParameters.id : null
  console.log(`Calling /get prospect, id=${id}`)
  if (id) {
    const model = prospectModel(PROSPECT_TABLE_NAME)
    const prospects = await model.query('id').eq(id).exec()

    if (prospects && prospects.length > 0) {
      const prospect = {
        contactInformation: {
          ...prospects[0].contactInformation,
        },
      } as CreateProspectResponseDto

      return HttpUtils.createJsonResponse(200, prospect)
    }
  }

  return HttpUtils.createResponseWithoutBody(404)
}
