import { HttpUtils } from '../util/http-util'
import fetch from 'node-fetch'

/**
 * @openapi
 * components:
 *   schemas:
 *     SampleResponseDto:
 *       type: object
 *       properties:
 *         text:
 *           type: string
 *           description: Text response from httpbin.org.
 * /check:
 *   get:
 *     summary: Internet connectivity check
 *     description: Activate an invitation
 *     responses:
 *       200:
 *         description: Sample response from httpbin.org
 *         content:
 *           application/json:
 *             schema:
 *               $ref: '#/components/schemas/SampleResponseDto'
 */
export const handler = async (event: any) => {
  const response = await fetch('https://httpbin.org/post', {
    method: 'POST',
    body: 'a=1',
  })

  const text = await response.text()
  return HttpUtils.createJsonResponse(200, { text })
}
