import './App.css'
import { Container, Row } from 'react-bootstrap'
import { QueryClient, QueryClientProvider } from 'react-query'
import { ReactQueryDemo } from './ReactQueryDemo'
import { ReactQueryDevtools } from 'react-query/devtools'
import { Footer, Header } from '@principalhongkong/principal-ui'

const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className='App'>
        <Header />
        <Container>
          <Row>
            <ReactQueryDemo></ReactQueryDemo>
          </Row>
        </Container>
        <Footer />
      </div>
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  )
}

export default App
