import {
  useIsFetching,
  useMutation,
  useQuery,
  useQueryClient,
} from 'react-query'
import { Configuration, DefaultApi, ProspectsIdPutRequest } from './api-client'

const api = new DefaultApi(
  new Configuration({
    fetchApi: window.fetch.bind(window) as any,
    basePath: process.env.REACT_APP_API_BASE_PATH,
    headers: { Accept: `*` },
  }),
)

export const ReactQueryDemo = () => {
  // const fetchData = async () => {
  //   const response = await api.checkGet()
  //   return response.text
  // }

  const fetchProspect = async () => {
    const response = await api.prospectsIdGet({
      id: '5341bc6b-888b-455c-8b59-fc2ea8dc5e7a',
    })
    return response.contactInformation
  }

  // Access the client
  const queryClient = useQueryClient()

  // Queries
  const {
    data: prospect,
    status: fetchProspectStatus,
    error: fetchProspectError,
  } = useQuery('prospect', fetchProspect, {
    onSuccess: () => {},
  })

  const isProspectFetching = useIsFetching(['prospect'])

  const handleFetch = () => {
    queryClient.invalidateQueries('prospect')
  }

  const onSubmit = (event: any) => {
    event.preventDefault()
  }

  const mutateContactInformation = useMutation(
    (contactInformation: any) => {
      return api.prospectsIdPut({
        id: '5341bc6b-888b-455c-8b59-fc2ea8dc5e7a',
        createProspectRequestDto: {
          ...prospect,
          contactInformation: { firstName: 'asd' },
        },
      } as ProspectsIdPutRequest)
    },
    {
      onSuccess: () => {
        queryClient.invalidateQueries('prospect')
      },
    },
  )

  return (
    <div>
      <div className='p-4'>
        <button
          onClick={handleFetch}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Fetch
        </button>
      </div>
      <div>{JSON.stringify(prospect)}</div>
      <div className='bg-green-500'>{fetchProspectStatus}</div>
      <div className='bg-green-400'>
        {isProspectFetching ? 'fetching' : 'done'}
      </div>
      <div className='bg-red-400'>
        {fetchProspectError ? JSON.stringify(fetchProspectError) : ''}
      </div>
      <div className='p-8'>
        <form onSubmit={onSubmit} className='w-full max-w-lg'>
          <div className='flex flex-wrap -mx-3 mb-6'>
            <div className='w-full md:w-1/2 px-3 mb-6 md:mb-0'>
              <label
                className='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                htmlFor='grid-first-name'
              >
                First Name
              </label>
              <input
                className='appearance-none block w-full bg-gray-200 text-gray-700 border border-red-500 rounded py-3 px-4 mb-3 leading-tight focus:outline-none focus:bg-white'
                id='grid-first-name'
                type='text'
                placeholder='Jane'
              />
              {/* <p className='text-red-500 text-xs italic'>
              Please fill out this field.
            </p> */}
            </div>
            <div className='w-full md:w-1/2 px-3'>
              <label
                className='block uppercase tracking-wide text-gray-700 text-xs font-bold mb-2'
                htmlFor='grid-last-name'
              >
                Last Name
              </label>
              <input
                className='appearance-none block w-full bg-gray-200 text-gray-700 border border-gray-200 rounded py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-gray-500'
                id='grid-last-name'
                type='text'
                placeholder='Doe'
              />
            </div>
          </div>
          <div className='flex items-center justify-between'>
            <button
              className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline'
              type='button'
              onClick={() => {
                mutateContactInformation.mutate({
                  firstName: 'ASD',
                  lastName: 'asd',
                })
              }}
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
