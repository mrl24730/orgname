import * as cdk from '@aws-cdk/core'
import { CfnOutput } from '@aws-cdk/core'
import { CloudfrontWebappStack } from './cloudfront-webapp-stack'
import { DynamoStack } from './dynamo-stack'
import { S3WebappStack } from './s3-webapp-stack'
import { VpcStack } from './vpc-stack'

export class BootstrapStack extends cdk.Stack {
  vpcResources: VpcStack
  s3WebappResources: S3WebappStack
  cloudfrontResources: CloudfrontWebappStack
  dynamoResource: DynamoStack

  constructor(scope: cdk.Construct, id: string, props?: cdk.StackProps) {
    super(scope, id, props)

    this.vpcResources = new VpcStack(this, 'vpcResources')
    this.s3WebappResources = new S3WebappStack(this, 's3WebappResources')
    this.cloudfrontResources = new CloudfrontWebappStack(
      this,
      'cloudfrontResources',
      {
        s3WebappBucket: this.s3WebappResources.s3WebappBucket,
      },
    )
    this.dynamoResource = new DynamoStack(this, 'dynamoResource')

    this.cloudfrontResources.addDependency(this.s3WebappResources)

    new CfnOutput(this, 'CfnOutputVpcId', {
      description: 'The vpc id',
      exportName: 'DecumulationVpcId',
      value: this.vpcResources.vpc.vpcId,
    })

    new CfnOutput(this, 'CfnOutputCloudfrontDistributionDomainName', {
      description: 'The S3 bucket name for the webapp',
      exportName: 'DecumulationCloudfrontDistributionDomainName',
      value: this.cloudfrontResources.cloudfrontDistribution.domainName,
    })

    new CfnOutput(this, 'CfnOutputS3WebappBucketName', {
      description: 'The S3 bucket name for the webapp',
      exportName: 'DecumulationS3WebappBucketName',
      value: this.s3WebappResources.s3WebappBucket.bucketName,
    })
  }
}
