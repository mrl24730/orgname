import * as cdk from '@aws-cdk/core'
import * as s3 from '@aws-cdk/aws-s3'
import { Bucket } from '@aws-cdk/aws-s3'
import * as cloudfront from '@aws-cdk/aws-cloudfront'
import * as origins from '@aws-cdk/aws-cloudfront-origins'
import { TagHelper } from '@pihk-decumulation/cdk-shared/util/tag-helper'
import { CfnOutput } from '@aws-cdk/core'

interface CloudfrontWebappStackProps extends cdk.NestedStackProps {
  s3WebappBucket: Bucket
}

export class CloudfrontWebappStack extends cdk.NestedStack {
  cloudfrontDistribution: cloudfront.Distribution

  constructor(
    scope: cdk.Construct,
    id: string,
    props: CloudfrontWebappStackProps,
  ) {
    super(scope, id, props)

    const { s3WebappBucket } = props

    this.cloudfrontDistribution = new cloudfront.Distribution(
      this,
      'decumulation-hk-cloudfront-dist',
      {
        defaultBehavior: { origin: new origins.S3Origin(s3WebappBucket) },
        defaultRootObject: 'index.html',
      },
    )

    TagHelper.addBaseTags(
      'decumulation-hk-cloudfront-dist',
      this.cloudfrontDistribution,
    )
  }
}
