import * as cdk from '@aws-cdk/core'
import * as s3 from '@aws-cdk/aws-s3'
import { Bucket } from '@aws-cdk/aws-s3'
import { TagHelper } from '@pihk-decumulation/cdk-shared/util/tag-helper'
import { CfnOutput, RemovalPolicy } from '@aws-cdk/core'

export class S3WebappStack extends cdk.NestedStack {
  s3WebappBucket: Bucket

  constructor(scope: cdk.Construct, id: string, props?: cdk.NestedStackProps) {
    super(scope, id, props)

    this.s3WebappBucket = new s3.Bucket(this, 'decumulation-hk-webapp', {
      versioned: false,
      removalPolicy: RemovalPolicy.RETAIN,
    })

    TagHelper.addBaseTags('decumulation-hk-webapp', this.s3WebappBucket)
  }
}
