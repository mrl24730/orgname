import {
  CfnNatGateway,
  Peer,
  Port,
  SecurityGroup,
  SubnetType,
  Vpc,
} from '@aws-cdk/aws-ec2'
import {
  Construct,
  NestedStack,
  NestedStackProps,
  Tag,
  Tags,
} from '@aws-cdk/core'
import { FixedIpNatGatewayProvider } from '@pihk-decumulation/cdk-shared/util/fixed-ip-nat-gateway.provider'
import { TagHelper } from '@pihk-decumulation/cdk-shared/util/tag-helper'

//ref https://dev.to/ryands17/using-nested-stacks-with-aws-cdk-4akc
export class VpcStack extends NestedStack {
  vpc: Vpc

  constructor(scope: Construct, id: string, props?: NestedStackProps) {
    super(scope, id, props)

    const EIP_ID = 'eipalloc-08fd62f26cbc4a91b'

    // const natGatewayProvider = ec2.NatProvider.gateway({
    //   eipAllocationIds: ['eipalloc-08fd62f26cbc4a91b'],
    // })

    this.vpc = new Vpc(this, 'decumulation-hk-vpc', {
      cidr: '192.168.0.0/16',
      natGateways: 1,
      natGatewayProvider: new FixedIpNatGatewayProvider({
        allocationIds: [EIP_ID],
      }),
      enableDnsHostnames: true,
      enableDnsSupport: true,
      maxAzs: 3,
      subnetConfiguration: [
        {
          name: 'ingress',
          subnetType: SubnetType.PRIVATE,
          cidrMask: 24,
        },

        {
          name: 'application',
          subnetType: SubnetType.PUBLIC,
          cidrMask: 24,
        },
      ],
    })
    TagHelper.addBaseTags(
      'decumulation-hk-networking/decumulation-hk-vpc',
      this.vpc,
    )

    let cnt = 1
    for (const publicSubnet of this.vpc.publicSubnets) {
      TagHelper.addBaseTags(
        `decumulation-hk-networking/decumulation-hk-vpc/publicSubnet${cnt++}`,
        publicSubnet,
      )
    }
    cnt = 1
    for (const privateSubnet of this.vpc.privateSubnets) {
      TagHelper.addBaseTags(
        `decumulation-hk-networking/decumulation-hk-vpc/privateSubnet${cnt++}`,
        privateSubnet,
      )
    }

    const privateInstanceSg = new SecurityGroup(
      this,
      'decumulation-hk-private-instance-sg',
      {
        vpc: this.vpc,
        securityGroupName: 'decumulation-hk-private-instance',
      },
    )
    Tags.of(privateInstanceSg).add('Name', 'decumulation-hk-private-instance')

    const publicInstanceSg = new SecurityGroup(
      this,
      'decumulation-hk-public-instance-sg',
      {
        vpc: this.vpc,
        securityGroupName: 'decumulation-hk-public-instance',
      },
    )
    Tags.of(publicInstanceSg).add('Name', 'decumulation-hk-public-instance')
  }
}
