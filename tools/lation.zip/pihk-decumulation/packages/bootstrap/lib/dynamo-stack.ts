import * as cdk from '@aws-cdk/core'
import { Duration, NestedStackProps, Tags } from '@aws-cdk/core'
import { AttributeType, ITable, Table } from '@aws-cdk/aws-dynamodb'
import { EXPORT_PROSPECT_TABLE_ARN_NAME } from '@pihk-decumulation/cdk-shared/constants'
export class DynamoStack extends cdk.NestedStack {
  prospectTable: ITable

  constructor(scope: cdk.Construct, id: string, props?: NestedStackProps) {
    super(scope, id, props)

    this.prospectTable = new Table(this, 'prospectTable', {
      partitionKey: { name: 'id', type: AttributeType.STRING },
    })

    new cdk.CfnOutput(this, 'CfnProspectTableArn', {
      value: this.prospectTable.tableArn,
      exportName: EXPORT_PROSPECT_TABLE_ARN_NAME,
    })
  }
}
